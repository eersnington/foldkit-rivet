import { describe, expectTypeOf, it, test } from "@effect/vitest";
import {
	Action,
	Actor,
	Client,
	Event,
	type Registry,
	type RivetError,
	type State,
	Workflow,
} from "@rivetkit/effect";
import {
	Context,
	DateTime,
	Duration,
	Effect,
	type Layer,
	type Option,
	Schema,
	SchemaTransformation,
	Scope,
	type Stream,
} from "effect";
import { HttpServerRequest, HttpServerResponse } from "effect/http";
import { Socket } from "effect/socket";
import { SqlClient } from "effect/sql";
import type { RawAccess } from "rivetkit/db";
import { db } from "rivetkit/db";

class SomeDep extends Context.Service<SomeDep, { readonly x: number }>()(
	"SomeDep",
) {}

class BodyBuilderDep extends Context.Service<
	BodyBuilderDep,
	{ readonly x: number }
>()("BodyBuilderDep") {}

class ActionsDep extends Context.Service<ActionsDep, { readonly x: number }>()(
	"ActionsDep",
) {}

const Ping = Action.make("Ping", {
	success: Schema.Number,
	error: Schema.String,
});

const TestActor = Actor.make("TestActor", {
	actions: [Ping],
});

const Reset = Action.make("Reset", {
	payload: { to: Schema.Number },
});

const Archive = Action.make("Archive", {
	payload: { to: Schema.Number },
});

const ScheduleActor = Actor.make("ScheduleActor", {
	actions: [Ping, Reset],
});

const scheduleActorHandlers = ScheduleActor.of({
	Ping: () => Effect.succeed(0),
	Reset: () => Effect.void,
});

const Moved = Event.make("Moved", { payload: { to: Schema.Number } });
const Pinged = Event.make("Pinged");
const Undeclared = Event.make("Undeclared");

const EventActor = Actor.make("EventActor", {
	actions: [Ping],
	events: [Moved, Pinged],
});

const GuardedActor = Actor.make("GuardedActor", {
	actions: [Ping],
	connection: {
		params: Schema.Struct({
			userId: Schema.String,
			joinedAt: Schema.DateTimeUtc,
		}),
	},
});

const SeededInput = Schema.Struct({
	owner: Schema.String,
	openedAt: Schema.DateTimeUtc,
});

const SeededActor = Actor.make("SeededActor", {
	actions: [Ping],
	input: SeededInput,
});

const TestState = {
	schema: Schema.Struct({
		count: Schema.Number,
	}),
	initialValue: () => ({ count: 0 }),
};

const TagsCsv = Schema.String.pipe(
	Schema.decodeTo(
		Schema.Array(Schema.String),
		SchemaTransformation.transform({
			decode: (s: string): ReadonlyArray<string> => s.split(","),
			encode: (arr: ReadonlyArray<string>) => arr.join(","),
		}),
	),
);

const ServiceDependentNumber = Schema.Number.pipe(
	Schema.decodeTo(
		Schema.Number,
		SchemaTransformation.transformEffect({
			decode: (n: number) =>
				Effect.gen(function* () {
					const dep = yield* SomeDep;
					return n + dep.x;
				}),
			encode: (n: number) =>
				Effect.gen(function* () {
					const dep = yield* SomeDep;
					return n - dep.x;
				}),
		}),
	),
);

class ServiceDependentError extends Schema.TaggedError<ServiceDependentError>()(
	"ServiceDependentError",
	{
		limit: ServiceDependentNumber,
		message: Schema.String,
	},
) {}

const ServiceDependentAction = Action.make("ServiceDependentAction", {
	payload: { amount: ServiceDependentNumber },
	success: ServiceDependentNumber,
	error: ServiceDependentError,
});

const ServiceDependentActor = Actor.make("ServiceDependentActor", {
	actions: [ServiceDependentAction],
});

const ServiceDependentState = {
	schema: Schema.Struct({
		count: ServiceDependentNumber,
	}),
	initialValue: () => ({ count: 0 }),
};

const TransformedState = {
	schema: Schema.Struct({
		when: Schema.DateFromString,
		url: Schema.URLFromString,
		id: Schema.BigIntFromString,
		bytes: Schema.Uint8ArrayFromBase64,
		tags: TagsCsv,
		history: Schema.Array(
			Schema.Struct({
				at: Schema.DateFromString,
				payload: Schema.Uint8ArrayFromBase64,
			}),
		),
	}),
	initialValue: () => ({
		when: new Date("2024-01-15T10:30:00.000Z"),
		url: new URL("https://rivet.dev/docs"),
		id: 1n,
		bytes: new Uint8Array([1, 2, 3]),
		tags: ["alpha", "beta"],
		history: [
			{
				at: new Date("2024-01-15T10:30:00.000Z"),
				payload: new Uint8Array([4, 5, 6]),
			},
		],
	}),
};

describe("Actor.make", () => {
	test("preserves the name literal", () => {
		expectTypeOf(TestActor.name).toEqualTypeOf<"TestActor">();
	});
});

describe("Actor.make(...).toLayer", () => {
	test("is a function", () => {
		expectTypeOf(TestActor.toLayer).toBeFunction();
	});

	test("accepts a plain action handlers object", () => {
		expectTypeOf(TestActor.toLayer).toBeCallableWith({
			Ping: () => Effect.succeed(0),
		});
	});

	test("accepts an effect of action handlers", () => {
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			Effect.gen(function* () {
				return {
					Ping: () => Effect.succeed(0),
				};
			}),
		);
	});

	test("accepts a function returning a plain action handlers object", () => {
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			(_wakeOptions: any) => ({
				Ping: () => Effect.succeed(0),
			}),
		);
	});

	test("accepts Duration inputs for RivetKit timeout options", () => {
		TestActor.toLayer(
			{ Ping: () => Effect.succeed(0) },
			{
				sleepTimeout: "5 minutes",
				actionTimeout: Duration.seconds(10),
				sleepGracePeriod: 15_000,
				maxSchedules: 100,
				canHibernateWebSocket: (request) => request.url.includes("ws"),
			},
		);
	});

	test("rejects deprecated RivetKit options", () => {
		TestActor.toLayer(
			{ Ping: () => Effect.succeed(0) },
			{
				// @ts-expect-error: noSleep is deprecated; use keepAwake instead
				noSleep: true,
			},
		);
	});

	test("wake options omit state without a configured state type", () => {
		TestActor.toLayer((wakeOptions) => {
			// @ts-expect-error: stateless actors do not expose wakeOptions.state
			wakeOptions.state;
			expectTypeOf(
				wakeOptions.rawRivetkitContext.state,
			).toEqualTypeOf<never>();

			return {
				Ping: () => Effect.succeed(0),
			};
		});

		TestActor.toLayer((wakeOptions) => {
			// @ts-expect-error: actors without a state option do not expose wakeOptions.state
			wakeOptions.state;

			expectTypeOf(
				wakeOptions.rawRivetkitContext.state,
			).toEqualTypeOf<never>();

			return {
				Ping: () => Effect.succeed(0),
			};
		}, {});
	});

	test("wake options carry the configured state type", () => {
		TestActor.toLayer(
			(wakeOptions) => {
				expectTypeOf(wakeOptions.state).toEqualTypeOf<
					State.State<{ readonly count: number }, Schema.SchemaError>
				>();

				return {
					Ping: () => Effect.succeed(0),
				};
			},
			{ state: TestState },
		);
	});

	test("state schema services surface in State effects and actor layers", () => {
		const layer = TestActor.toLayer(
			(wakeOptions) => {
				type StateGetServices = Effect.Services<
					typeof wakeOptions.state.get
				>;

				expectTypeOf<SomeDep>().toExtend<StateGetServices>();

				return {
					Ping: () =>
						wakeOptions.state.get.pipe(
							Effect.map((current) => current.count),
							Effect.orDie,
						),
				};
			},
			{ state: ServiceDependentState },
		);
		type LayerServices = Layer.Services<typeof layer>;
		type LayerHasSomeDep = SomeDep extends LayerServices ? true : false;

		expectTypeOf<LayerHasSomeDep>().toEqualTypeOf<true>();
	});

	test("wake options carry the transformed state type", () => {
		TestActor.toLayer(
			(wakeOptions) => {
				expectTypeOf(wakeOptions.state).toEqualTypeOf<
					State.State<
						{
							readonly when: Date;
							readonly url: URL;
							readonly id: bigint;
							readonly bytes: Uint8Array;
							readonly tags: ReadonlyArray<string>;
							readonly history: ReadonlyArray<{
								readonly at: Date;
								readonly payload: Uint8Array;
							}>;
						},
						Schema.SchemaError
					>
				>();

				return {
					Ping: () => Effect.succeed(0),
				};
			},
			{ state: TransformedState },
		);
	});

	test("wake options carry the raw RivetKit context with the encoded configured state type", () => {
		TestActor.toLayer(
			(wakeOptions) => {
				expectTypeOf(
					wakeOptions.rawRivetkitContext.state,
				).toEqualTypeOf<{ readonly count: number }>();

				return {
					Ping: () => Effect.succeed(0),
				};
			},
			{ state: TestState },
		);
	});

	test("wake options carry the raw RivetKit context with the encoded transformed state type", () => {
		TestActor.toLayer(
			(wakeOptions) => {
				expectTypeOf(
					wakeOptions.rawRivetkitContext.state,
				).toEqualTypeOf<{
					readonly when: string;
					readonly url: string;
					readonly id: string;
					readonly bytes: string;
					readonly tags: string;
					readonly history: ReadonlyArray<{
						readonly at: string;
						readonly payload: string;
					}>;
				}>();

				return {
					Ping: () => Effect.succeed(0),
				};
			},
			{ state: TransformedState },
		);
	});

	test("wake options carry the configured database client type", () => {
		TestActor.toLayer(
			(wakeOptions) => {
				expectTypeOf(
					wakeOptions.rawRivetkitContext.db,
				).toEqualTypeOf<RawAccess>();
				expectTypeOf(
					wakeOptions.rawRivetkitContext.db.transaction(
						async () => {},
						{ name: "effect-operation", timeout: 1_000 },
					),
				).toEqualTypeOf<Promise<void>>();

				return {
					Ping: () => Effect.succeed(0),
				};
			},
			{ db: db() },
		);
	});

	test("accepts a function returning an effect of action handlers", () => {
		expectTypeOf(TestActor.toLayer).toBeCallableWith((_wakeOptions: any) =>
			Effect.gen(function* () {
				return {
					Ping: () => Effect.succeed(0),
				};
			}),
		);
	});

	test("accepts an effect that resolves to a wake function", () => {
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			Effect.gen(function* () {
				// Allow for initialization logic before the per-entity wake function is called

				return (_wakeOptions: any) =>
					Effect.gen(function* () {
						return {
							Ping: () => Effect.succeed(0),
						};
					});
			}),
		);
	});

	test("accepts an Effect.fn returning action handlers", () => {
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			Effect.fn("wake")(function* (_wakeOptions) {
				return {
					Ping: () => Effect.succeed(0),
				};
			}),
		);
	});

	test("returns a Layer", () => {
		expectTypeOf(TestActor.toLayer).returns.toExtend<Layer.Any>();
	});

	test("action handler's envelope is typed against the action", () => {
		TestActor.toLayer({
			Ping: (envelope) => {
				expectTypeOf(envelope._tag).toEqualTypeOf<"Ping">();
				expectTypeOf(envelope.action).toExtend<Action.Any>();
				return Effect.succeed(0);
			},
		});
	});

	test("action handler return success is type checked", () => {
		// Plain action handlers object.
		expectTypeOf(TestActor.toLayer).toBeCallableWith({
			Ping: () => Effect.succeed(0),
		});

		TestActor.toLayer({
			// @ts-expect-error: Ping must return the declared number success type.
			Ping: () => Effect.succeed("not a number"),
		});

		// Effect of action handlers.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			Effect.gen(function* () {
				return {
					Ping: () => Effect.succeed(0),
				};
			}),
		);

		TestActor.toLayer(
			// @ts-expect-error: Ping must return the declared number success type.
			Effect.gen(function* () {
				return {
					Ping: () => Effect.succeed("not a number"),
				};
			}),
		);

		// Function returning a plain action handlers object.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(() => ({
			Ping: () => Effect.succeed(0),
		}));

		// @ts-expect-error: Ping must return the declared number success type.
		TestActor.toLayer(() => ({
			Ping: () => Effect.succeed("not a number"),
		}));

		// Function returning an effect of action handlers.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(() =>
			Effect.gen(function* () {
				return {
					Ping: () => Effect.succeed(0),
				};
			}),
		);

		// @ts-expect-error: Ping must return the declared number success type.
		TestActor.toLayer(() =>
			Effect.gen(function* () {
				return {
					Ping: () => Effect.succeed("not a number"),
				};
			}),
		);

		// Effect that resolves to a wake function.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			Effect.gen(function* () {
				return () => ({
					Ping: () => Effect.succeed(0),
				});
			}),
		);

		TestActor.toLayer(
			// @ts-expect-error: Ping must return the declared number success type.
			Effect.gen(function* () {
				return () => ({
					Ping: () => Effect.succeed("not a number"),
				});
			}),
		);

		// Effect.fn returning action handlers.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			Effect.fn("wake")(function* () {
				return {
					Ping: () => Effect.succeed(0),
				};
			}),
		);

		TestActor.toLayer(
			// @ts-expect-error: Ping must return the declared number success type.
			Effect.fn("wake")(function* () {
				return {
					Ping: () => Effect.succeed("not a number"),
				};
			}),
		);
	});

	test("action handler return error is type checked", () => {
		// Plain action handlers object.
		expectTypeOf(TestActor.toLayer).toBeCallableWith({
			Ping: () => Effect.succeed(0),
		});

		TestActor.toLayer({
			// @ts-expect-error: Ping can only fail with its declared action error type.
			// @effect-diagnostics effect/missingEffectError:off
			Ping: () => Effect.fail(1),
		});

		// Effect of action handlers.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			Effect.gen(function* () {
				return {
					Ping: () => Effect.succeed(0),
				};
			}),
		);

		TestActor.toLayer(
			// @ts-expect-error: Ping can only fail with its declared action error type.
			Effect.gen(function* () {
				return {
					// @effect-diagnostics effect/missingEffectError:off
					Ping: () => Effect.fail(1),
				};
			}),
		);

		// Function returning a plain action handlers object.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(() => ({
			Ping: () => Effect.succeed(0),
		}));

		// @ts-expect-error: Ping can only fail with its declared action error type.
		TestActor.toLayer(() => ({
			// @effect-diagnostics effect/missingEffectError:off
			Ping: () => Effect.fail(1),
		}));

		// Function returning an effect of action handlers.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(() =>
			Effect.gen(function* () {
				return {
					Ping: () => Effect.succeed(0),
				};
			}),
		);

		// @ts-expect-error: Ping can only fail with its declared action error type.
		TestActor.toLayer(() =>
			Effect.gen(function* () {
				return {
					// @effect-diagnostics effect/missingEffectError:off
					Ping: () => Effect.fail(1),
				};
			}),
		);

		// Effect that resolves to a wake function.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			Effect.gen(function* () {
				return () => ({
					Ping: () => Effect.succeed(0),
				});
			}),
		);

		TestActor.toLayer(
			// @ts-expect-error: Ping can only fail with its declared action error type.
			Effect.gen(function* () {
				return () => ({
					// @effect-diagnostics effect/missingEffectError:off
					Ping: () => Effect.fail(1),
				});
			}),
		);

		// Effect.fn returning action handlers.
		expectTypeOf(TestActor.toLayer).toBeCallableWith(
			Effect.fn("wake")(function* () {
				return {
					Ping: () => Effect.succeed(0),
				};
			}),
		);

		TestActor.toLayer(
			// @ts-expect-error: Ping can only fail with its declared action error type.
			Effect.fn("wake")(function* () {
				return {
					// @effect-diagnostics effect/missingEffectError:off
					Ping: () => Effect.fail(1),
				};
			}),
		);
	});

	test("schedule accepts only this actor's actions", () => {
		ScheduleActor.toLayer(
			Effect.gen(function* () {
				const schedule = yield* ScheduleActor.schedule;
				expectTypeOf(
					schedule.after("1 second", Reset, { to: 0 }),
				).toEqualTypeOf<Effect.Effect<string, RivetError.RivetError>>();
				// @ts-expect-error: Archive is not one of ScheduleActor's actions
				schedule.after("1 second", Archive, { to: 0 });
				// @ts-expect-error: schedule takes an action, not a tag
				schedule.after("1 second", "Reset", { to: 0 });

				return scheduleActorHandlers;
			}),
		);
	});

	test("schedule omits the payload only for no-payload actions", () => {
		ScheduleActor.toLayer(
			Effect.gen(function* () {
				const schedule = yield* ScheduleActor.schedule;
				expectTypeOf(schedule.after("1 second", Ping)).toEqualTypeOf<
					Effect.Effect<string, RivetError.RivetError>
				>();
				expectTypeOf(schedule.at(new Date(), Ping)).toEqualTypeOf<
					Effect.Effect<string, RivetError.RivetError>
				>();
				// @ts-expect-error: Reset requires a payload
				schedule.after("1 second", Reset);

				return scheduleActorHandlers;
			}),
		);
	});

	test("cron accepts only this actor's actions and their payloads", () => {
		const layer = ScheduleActor.toLayer(
			Effect.gen(function* () {
				const cron = yield* ScheduleActor.cron;
				expectTypeOf(
					cron.set(
						{ name: "daily", expression: "0 9 * * *" },
						Reset,
						{
							to: 0,
						},
					),
				).toEqualTypeOf<Effect.Effect<void, RivetError.RivetError>>();
				expectTypeOf(
					cron.every({ name: "tick", interval: "1 minute" }, Ping),
				).toEqualTypeOf<Effect.Effect<void, RivetError.RivetError>>();
				// @ts-expect-error: Archive is not one of ScheduleActor's actions
				cron.set({ name: "daily", expression: "0 9 * * *" }, Archive, {
					to: 0,
				});
				// @ts-expect-error: Archive is not one of ScheduleActor's actions
				cron.every({ name: "tick", interval: "1 minute" }, Archive, {
					to: 0,
				});
				// @ts-expect-error: Reset requires a payload
				cron.every({ name: "tick", interval: "1 minute" }, Reset);
				// @ts-expect-error: cron takes an action, not a tag
				cron.every({ name: "tick", interval: "1 minute" }, "Ping");

				return scheduleActorHandlers;
			}),
		);

		expectTypeOf<
			Layer.Services<typeof layer>
		>().toEqualTypeOf<Registry.Registry>();
	});

	test("events accepts only this actor's events and their payloads", () => {
		const connection = {} as Actor.ActionConnection;
		const layer = EventActor.toLayer(
			Effect.gen(function* () {
				const events = yield* EventActor.events;
				expectTypeOf(events.broadcast(Moved, { to: 1 })).toEqualTypeOf<
					Effect.Effect<void>
				>();
				expectTypeOf(events.send(connection, Pinged)).toEqualTypeOf<
					Effect.Effect<void>
				>();
				// @ts-expect-error: Undeclared is not one of EventActor's events
				events.broadcast(Undeclared);
				// @ts-expect-error: Undeclared is not one of EventActor's events
				events.send(connection, Undeclared);
				// @ts-expect-error: Moved's payload needs a number
				events.broadcast(Moved, { to: "1" });
				// @ts-expect-error: Moved requires a payload
				events.send(connection, Moved);
				// @ts-expect-error: broadcast takes an event, not a tag
				events.broadcast("Pinged");

				return EventActor.of({
					Ping: () =>
						EventActor.events.pipe(
							Effect.flatMap((events) =>
								events.broadcast(Pinged),
							),
							Effect.as(0),
						),
				});
			}),
		);

		expectTypeOf<
			Layer.Services<typeof layer>
		>().toEqualTypeOf<Registry.Registry>();
	});

	test("keepAwake, sleep, destroy and the actor's own schedule stay out of the layer requirements", () => {
		const layer = ScheduleActor.toLayer(
			Effect.gen(function* () {
				yield* Actor.keepAwake(Effect.void);
				yield* ScheduleActor.schedule;
				return ScheduleActor.of({
					Ping: () => Actor.keepAwake(Effect.succeed(0)),
					Reset: () =>
						ScheduleActor.schedule.pipe(
							Effect.andThen(Actor.sleep),
							Effect.andThen(Actor.destroy),
						),
				});
			}),
		);

		expectTypeOf<
			Layer.Services<typeof layer>
		>().toEqualTypeOf<Registry.Registry>();
	});

	test("another actor's schedule leaves the layer unservable", () => {
		const layer = ScheduleActor.toLayer(
			Effect.gen(function* () {
				yield* TestActor.schedule;
				return scheduleActorHandlers;
			}),
		);

		expectTypeOf(layer).not.toExtend<
			Layer.Layer<never, never, Registry.Registry>
		>();
	});

	test("another actor's events leave the layer unservable", () => {
		const layer = TestActor.toLayer(
			Effect.gen(function* () {
				yield* EventActor.events;
				return TestActor.of({ Ping: () => Effect.succeed(0) });
			}),
		);

		expectTypeOf(layer).not.toExtend<
			Layer.Layer<never, never, Registry.Registry>
		>();
	});

	test("connections lists params only for an actor that declares them", () => {
		Effect.gen(function* () {
			const [guarded] = yield* (yield* GuardedActor.connections).list;
			expectTypeOf(guarded.params).toEqualTypeOf<{
				readonly userId: string;
				readonly joinedAt: DateTime.Utc;
			}>();

			const connections = yield* TestActor.connections;
			const [unguarded] = yield* connections.list;
			expectTypeOf(connections.disconnect(guarded)).toEqualTypeOf<
				Effect.Effect<void, RivetError.RivetError>
			>();
			// @ts-expect-error: TestActor declares no connection params
			unguarded.params;
		});
	});

	test("another actor's connections leave the layer unservable", () => {
		const layer = TestActor.toLayer({
			Ping: () => Effect.as(GuardedActor.connections, 0),
		});

		expectTypeOf(layer).not.toExtend<
			Layer.Layer<never, never, Registry.Registry>
		>();
	});

	test("SqlClient stays a layer requirement unless the actor declares a db", () => {
		const useSqlClient = Effect.gen(function* () {
			yield* SqlClient.SqlClient;
			return 0;
		});
		const wake = Effect.as(
			useSqlClient,
			TestActor.of({ Ping: () => useSqlClient }),
		);

		const withoutDb = TestActor.toLayer(wake);
		const withOptionsWithoutDb = TestActor.toLayer(wake, {
			sleepTimeout: "1 minute",
		});
		const withDb = TestActor.toLayer(wake, { db: db() });

		expectTypeOf<Layer.Services<typeof withoutDb>>().toEqualTypeOf<
			Registry.Registry | SqlClient.SqlClient
		>();
		expectTypeOf<
			Layer.Services<typeof withOptionsWithoutDb>
		>().toEqualTypeOf<Registry.Registry | SqlClient.SqlClient>();
		expectTypeOf<
			Layer.Services<typeof withDb>
		>().toEqualTypeOf<Registry.Registry>();
	});

	test("sql is the actor's SqlClient, only for an actor that declares a db", () => {
		const useSql = Effect.gen(function* () {
			expectTypeOf(
				yield* TestActor.sql,
			).toEqualTypeOf<SqlClient.SqlClient>();
			return 0;
		});
		const wake = Effect.as(useSql, TestActor.of({ Ping: () => useSql }));

		const withDb = TestActor.toLayer(wake, {
			db: db(),
			onCreate: () => Effect.asVoid(TestActor.sql),
			onMigrate: () => Effect.asVoid(TestActor.sql),
		});
		expectTypeOf<
			Layer.Services<typeof withDb>
		>().toEqualTypeOf<Registry.Registry>();

		const withoutDb = TestActor.toLayer(wake);
		expectTypeOf(withoutDb).not.toExtend<
			Layer.Layer<never, never, Registry.Registry>
		>();
	});

	test("another actor's sql leaves the layer unservable", () => {
		const layer = TestActor.toLayer(
			{ Ping: () => Effect.as(ScheduleActor.sql, 0) },
			{ db: db() },
		);

		expectTypeOf(layer).not.toExtend<
			Layer.Layer<never, never, Registry.Registry>
		>();
	});

	test("onCreate gets the decoded input and only pre-wake services", () => {
		const handlers = SeededActor.of({ Ping: () => Effect.succeed(0) });
		const layer = SeededActor.toLayer(handlers, {
			db: db(),
			onCreate: (input) =>
				Effect.gen(function* () {
					expectTypeOf(input).toEqualTypeOf<
						typeof SeededInput.Type
					>();
					yield* SqlClient.SqlClient;
					yield* Actor.CurrentAddress;
					yield* SomeDep;
				}),
		});
		expectTypeOf<Layer.Services<typeof layer>>().toEqualTypeOf<
			Registry.Registry | SomeDep
		>();

		const withoutInstance = SeededActor.toLayer(handlers, {
			onCreate: () => Effect.asVoid(Actor.Sleep),
		});
		expectTypeOf<Layer.Services<typeof withoutInstance>>().toEqualTypeOf<
			Registry.Registry | Actor.Sleep
		>();

		TestActor.toLayer(
			{ Ping: () => Effect.succeed(0) },
			{
				onCreate: (input) =>
					Effect.sync(() => {
						expectTypeOf(input).toEqualTypeOf<undefined>();
					}),
			},
		);
	});

	test("onMigrate gets isNew and only pre-wake services", () => {
		const handlers = TestActor.of({ Ping: () => Effect.succeed(0) });
		const layer = TestActor.toLayer(handlers, {
			db: db(),
			onMigrateTimeout: "1 minute",
			onMigrate: ({ isNew }) =>
				Effect.gen(function* () {
					expectTypeOf(isNew).toEqualTypeOf<boolean>();
					yield* SqlClient.SqlClient;
					yield* Actor.CurrentAddress;
					yield* SomeDep;
				}),
			onCreate: () => Effect.asVoid(Actor.KeepAwake),
		});
		expectTypeOf<Layer.Services<typeof layer>>().toEqualTypeOf<
			Registry.Registry | SomeDep | Actor.KeepAwake
		>();
	});

	test("missing action handler is rejected", () => {
		// @ts-expect-error: Ping handler is required
		TestActor.toLayer({});
	});

	test.todo("unknown action handler key is rejected", () => {
		TestActor.toLayer({
			Ping: () => Effect.succeed(0),
			// TODO: toLayer should reject unknown action handler keys
			Unknown: () => Effect.void,
		});
	});

	test.todo("wake-effect requirements surface in the Layer", () => {
		const layer = TestActor.toLayer(
			Effect.gen(function* () {
				yield* SomeDep;
				return { Ping: () => Effect.succeed(0) };
			}),
		);
		type Reqs =
			typeof layer extends Layer.Layer<any, any, infer R> ? R : never;
		// @ts-expect-error: TODO - expectTypeOf<T>() no-arg generic form not resolving
		expectTypeOf<SomeDep>().toExtend<Reqs>();
	});
});

describe("Actor.make(...).of", () => {
	test("preserves the action handlers object type", () => {
		const handlers = {
			Ping: () => Effect.succeed(0),
		};

		expectTypeOf(TestActor.of(handlers)).toEqualTypeOf<typeof handlers>();
	});

	test("action handler's envelope is typed against the action", () => {
		TestActor.of({
			Ping: (envelope) => {
				expectTypeOf(envelope._tag).toEqualTypeOf<"Ping">();
				expectTypeOf(envelope.action).toEqualTypeOf<typeof Ping>();
				return Effect.succeed(0);
			},
		});
	});

	test("action handler return success is type checked", () => {
		expectTypeOf(TestActor.of).toBeCallableWith({
			Ping: () => Effect.succeed(0),
		});

		TestActor.of({
			// @ts-expect-error: Ping must return the declared number success type.
			Ping: () => Effect.succeed("not a number"),
		});
	});

	test("action handler return error is type checked", () => {
		expectTypeOf(TestActor.of).toBeCallableWith({
			Ping: () => Effect.succeed(0),
		});

		TestActor.of({
			// @ts-expect-error: Ping can only fail with its declared action error type.
			// @effect-diagnostics effect/missingEffectError:off
			Ping: () => Effect.fail(1),
		});
	});
});

describe("Actor.make(...).client", () => {
	test("yields a typed Accessor", () => {
		expectTypeOf(TestActor.client).toEqualTypeOf<
			Effect.Effect<
				Actor.Accessor<(typeof TestActor.actions)[number]>,
				never,
				Client.Client
			>
		>();
	});

	test("create resolves to a Handle; the other accessors return one", () => {
		type Handle = Actor.Handle<(typeof TestActor.actions)[number]>;
		type Accessor = Actor.Accessor<(typeof TestActor.actions)[number]>;

		expectTypeOf<
			ReturnType<Accessor["getOrCreate"]>
		>().toEqualTypeOf<Handle>();
		expectTypeOf<ReturnType<Accessor["get"]>>().toEqualTypeOf<Handle>();
		expectTypeOf<
			ReturnType<Accessor["getForId"]>
		>().toEqualTypeOf<Handle>();
		expectTypeOf<ReturnType<Accessor["create"]>>().toEqualTypeOf<
			Effect.Effect<Handle, RivetError.RivetError>
		>();
	});

	it.effect("accessors take only the actor's connection params", () =>
		Effect.gen(function* () {
			const guarded = yield* GuardedActor.client;
			const params = {
				userId: "alice",
				joinedAt: DateTime.makeUnsafe(0),
			};
			guarded.getOrCreate("t-guarded", { params });
			guarded.get("t-guarded", { params });
			guarded.getForId("actor-id", { params });
			guarded.create("t-guarded", { params });

			// @ts-expect-error: GuardedActor requires connection params
			guarded.getOrCreate("t-guarded");
			guarded.get("t-guarded", {
				// @ts-expect-error: joinedAt is a DateTime.Utc, not a string
				params: { userId: "alice", joinedAt: "2026-01-01" },
			});
			// @ts-expect-error: joinedAt is missing
			guarded.getForId("actor-id", { params: { userId: "alice" } });
			guarded.create("t-guarded", {
				// @ts-expect-error: userId is a string
				params: { ...params, userId: 42 },
			});

			const plain = yield* TestActor.client;
			// @ts-expect-error: TestActor declares no connection params
			plain.getOrCreate("t-plain", { params });
		}).pipe(Effect.provide(Client.layer())),
	);

	test("a handle method wins over an action with the same name", () => {
		const Fetch = Action.make("fetch", { success: Schema.Number });
		const Fetcher = Actor.make("Fetcher", { actions: [Ping, Fetch] });
		type FetcherHandle = ReturnType<
			Effect.Success<typeof Fetcher.client>["getOrCreate"]
		>;
		type Handle = Actor.Handle<typeof Ping>;

		expectTypeOf<FetcherHandle["fetch"]>().toEqualTypeOf<Handle["fetch"]>();
		expectTypeOf<FetcherHandle["Ping"]>().toEqualTypeOf<Handle["Ping"]>();
	});

	test("connect yields typed actions and one stream per declared event", () => {
		type Handle = ReturnType<
			Effect.Success<typeof EventActor.client>["getOrCreate"]
		>;
		type Connection = Effect.Success<Handle["connect"]>;

		expectTypeOf<Connection["Ping"]>().toEqualTypeOf<Handle["Ping"]>();
		expectTypeOf<keyof Connection["events"]>().toEqualTypeOf<
			"Moved" | "Pinged"
		>();
		expectTypeOf<Connection["events"]["Moved"]>().toEqualTypeOf<
			Stream.Stream<{ readonly to: number }, RivetError.RivetError>
		>();
		expectTypeOf<Connection["events"]["Pinged"]>().toEqualTypeOf<
			Stream.Stream<void, RivetError.RivetError>
		>();
	});

	it.effect("only accessors that can create take the actor's input", () =>
		Effect.gen(function* () {
			const seeded = yield* SeededActor.client;
			const input = { owner: "alice", openedAt: DateTime.makeUnsafe(0) };
			seeded.getOrCreate("t-seeded", { createWithInput: input });
			seeded.create("t-seeded", { input });
			seeded.get("t-seeded");
			seeded.getForId("actor-id");

			// @ts-expect-error: SeededActor requires creation input
			seeded.getOrCreate("t-seeded");
			// @ts-expect-error: SeededActor requires creation input
			seeded.create("t-seeded");
			seeded.getOrCreate("t-seeded", {
				// @ts-expect-error: openedAt is a DateTime.Utc, not a string
				createWithInput: { owner: "alice", openedAt: "2026-01-01" },
			});
			// @ts-expect-error: owner is missing
			seeded.create("t-seeded", { input: { openedAt: input.openedAt } });
			// @ts-expect-error: get does not create the actor
			seeded.get("t-seeded", { input });

			const plain = yield* TestActor.client;
			// @ts-expect-error: TestActor declares no input
			plain.getOrCreate("t-plain", { createWithInput: input });
			// @ts-expect-error: TestActor declares no input
			plain.create("t-plain", { input });
		}).pipe(Effect.provide(Client.layer())),
	);

	it.effect("handle calls require client-side schema services", () =>
		Effect.gen(function* () {
			const actor = (yield* ServiceDependentActor.client).getOrCreate(
				"t-service-dependent",
			);
			const actionEffect = actor.ServiceDependentAction({ amount: 10 });
			type ActionClientServices = Effect.Services<typeof actionEffect>;

			expectTypeOf<SomeDep>().toExtend<ActionClientServices>();
		}).pipe(Effect.provide(Client.layer())),
	);
});

describe("Actor.of hooks", () => {
	test("the layer requires the http handler's services, not the ones the SDK provides", () => {
		const live = TestActor.toLayer(
			Effect.succeed(
				TestActor.of(
					{ Ping: () => Effect.succeed(1) },
					{
						http: Effect.gen(function* () {
							yield* HttpServerRequest.HttpServerRequest;
							yield* SqlClient.SqlClient;
							yield* Actor.CurrentAddress;
							yield* Effect.addFinalizer(() => Effect.void);
							const dep = yield* SomeDep;
							return HttpServerResponse.text(String(dep.x));
						}),
					},
				),
			),
			{ db: db({ onMigrate: async () => {} }) },
		);

		expectTypeOf<Layer.Services<typeof live>>().toEqualTypeOf<
			SomeDep | Registry.Registry
		>();
	});

	test("the webSocket handler gets the Socket and the upgrade request", () => {
		const live = TestActor.toLayer(
			TestActor.of(
				{ Ping: () => Effect.succeed(1) },
				{
					webSocket: Effect.gen(function* () {
						yield* Socket.Socket;
						yield* HttpServerRequest.HttpServerRequest;
						yield* Actor.CurrentAddress;
						yield* Effect.addFinalizer(() => Effect.void);
						yield* SomeDep;
					}),
				},
			),
		);

		expectTypeOf<Layer.Services<typeof live>>().toEqualTypeOf<
			SomeDep | Registry.Registry
		>();
	});

	test("connection hooks infer the params and share the layer's requirements", () => {
		const live = GuardedActor.toLayer(
			Effect.gen(function* () {
				yield* Actor.CurrentAddress;
				return GuardedActor.of(
					{ Ping: () => Effect.succeed(1) },
					{
						authorize: ({ userId, joinedAt }, request) => {
							expectTypeOf(userId).toEqualTypeOf<string>();
							expectTypeOf(
								joinedAt,
							).toEqualTypeOf<DateTime.Utc>();
							expectTypeOf(request).toEqualTypeOf<
								Option.Option<Request>
							>();
							return Effect.asVoid(SomeDep);
						},
						onConnect: ({ id, params }) => {
							expectTypeOf(id).toEqualTypeOf<string>();
							expectTypeOf(params.userId).toEqualTypeOf<string>();
							return Effect.asVoid(GuardedActor.connections);
						},
						onDisconnect: ({ params }) => {
							expectTypeOf(params.userId).toEqualTypeOf<string>();
							return Effect.asVoid(Actor.KeepAwake);
						},
					},
				);
			}),
		);

		expectTypeOf<Layer.Services<typeof live>>().toEqualTypeOf<
			SomeDep | Registry.Registry
		>();
	});

	test("an actor that declares connection must pass authorize", () => {
		const handlers = { Ping: () => Effect.succeed(1) };

		// @ts-expect-error: GuardedActor needs hooks with authorize
		GuardedActor.of(handlers);
		// @ts-expect-error: authorize is missing
		GuardedActor.of(handlers, { onConnect: () => Effect.void });
		// @ts-expect-error: plain handlers carry no authorize
		GuardedActor.toLayer(handlers);
		// @ts-expect-error: plain handlers carry no authorize
		GuardedActor.toLayer(Effect.succeed(handlers));

		// @ts-expect-error: TestActor declares no connection
		TestActor.of(handlers, { authorize: () => Effect.void });
	});

	test("onBeforeActionResponse gets an action's decoded request and success and returns that action's success", () => {
		const live = ScheduleActor.toLayer(
			ScheduleActor.of(scheduleActorHandlers, {
				onBeforeActionResponse: {
					Ping: (response) => {
						expectTypeOf(response._tag).toEqualTypeOf<"Ping">();
						expectTypeOf(response.payload).toEqualTypeOf<void>();
						expectTypeOf(response.success).toEqualTypeOf<number>();
						return Effect.gen(function* () {
							yield* ScheduleActor.schedule;
							const dep = yield* SomeDep;
							return response.success + dep.x;
						});
					},
				},
			}),
		);
		expectTypeOf<Layer.Services<typeof live>>().toEqualTypeOf<
			SomeDep | Registry.Registry
		>();

		ScheduleActor.of(scheduleActorHandlers, {
			onBeforeActionResponse: {
				// @ts-expect-error: Ping succeeds with a number, not Reset's void
				Ping: () => Effect.void,
			},
		});
		ScheduleActor.of(scheduleActorHandlers, {
			// @ts-expect-error: Archive is not an action of ScheduleActor
			onBeforeActionResponse: { Archive: () => Effect.void },
		});
	});
});

describe("workflow contract", () => {
	const TestWorkflow = Workflow.make("TestWorkflow", {
		actions: [Ping],
		events: [Moved],
	});
	const pingHandlers = { Ping: () => Effect.succeed(1) };

	test("the body gets Workflow and the handler services, a step keeps its result type, and the layer needs the services of the body builder, the body and actions", () => {
		const live = TestWorkflow.toLayer(
			Effect.gen(function* () {
				yield* BodyBuilderDep;
				yield* TestWorkflow.sql;
				yield* Scope.Scope;

				return Effect.gen(function* () {
					yield* SqlClient.SqlClient;
					yield* TestWorkflow.sql;
					yield* TestWorkflow.schedule;
					const at = yield* Workflow.step("now", DateTime.now, {
						schema: Schema.DateTimeUtc,
						timeout: "1 minute",
					});
					expectTypeOf(at).toEqualTypeOf<DateTime.Utc>();
					const dep = yield* Workflow.step("dep", SomeDep);
					expectTypeOf(dep).toEqualTypeOf<{ readonly x: number }>();
					yield* Workflow.sleep("wait", "1 hour");
				});
			}),
			{
				db: db({ onMigrate: async () => {} }),
				actions: Effect.gen(function* () {
					yield* ActionsDep;
					yield* TestWorkflow.sql;

					return TestWorkflow.of(pingHandlers);
				}),
			},
		);

		expectTypeOf<Layer.Services<typeof live>>().toEqualTypeOf<
			BodyBuilderDep | SomeDep | ActionsDep | Registry.Registry
		>();
	});

	test("a workflow contract needs the body builder, and actions when it declares actions or connection", () => {
		const body = Effect.succeed(Effect.void);

		TestWorkflow.toLayer(body, { actions: pingHandlers });
		TestWorkflow.toLayer(body, {
			actions: TestWorkflow.of(pingHandlers, {}),
		});
		// @ts-expect-error: actions is missing
		TestWorkflow.toLayer(body);
		// @ts-expect-error: actions is missing
		TestWorkflow.toLayer(body, { db: db() });
		// @ts-expect-error: the first argument builds the body
		TestWorkflow.toLayer(pingHandlers);
		// @ts-expect-error: a bare body is not an effect that succeeds with the body
		TestWorkflow.toLayer(Effect.void, { actions: pingHandlers });
		// @ts-expect-error: the Ping handler is missing
		TestWorkflow.toLayer(body, { actions: {} });
		TestWorkflow.toLayer(body, {
			// @ts-expect-error: Ping succeeds with a number
			actions: { Ping: () => Effect.succeed("pong") },
		});

		const Guarded = Workflow.make("Guarded", {
			connection: { params: Schema.Struct({ token: Schema.String }) },
		});
		// @ts-expect-error: connection needs authorize, so it needs actions
		Guarded.toLayer(body);
		// @ts-expect-error: authorize is missing
		Guarded.toLayer(body, { actions: {} });
		Guarded.toLayer(body, {
			actions: Guarded.of({}, { authorize: () => Effect.void }),
		});
	});

	test("a workflow contract without actions needs no actions", () => {
		const Bare = Workflow.make("Bare");
		const body = Effect.succeed(Workflow.step("only", SomeDep));

		const live = Bare.toLayer(body);
		expectTypeOf<Layer.Services<typeof live>>().toEqualTypeOf<
			SomeDep | Registry.Registry
		>();
		Bare.toLayer(body, { db: db() });
		Bare.toLayer(body, { actions: Bare.of({}) });
	});

	test("of takes no run, and an actor contract takes no actions", () => {
		// @ts-expect-error: run is not a hook
		TestWorkflow.of(pingHandlers, { run: Effect.void });
		// @ts-expect-error: run is not a hook
		TestActor.of(pingHandlers, { run: Effect.void });
		// @ts-expect-error: an actor contract takes no actions
		TestActor.toLayer(pingHandlers, { actions: pingHandlers });
		// @ts-expect-error: the first argument of an actor contract is not a body builder
		TestActor.toLayer(Effect.succeed(Effect.void));
	});

	test("a workflow contract has the client and the accessors of an actor contract", () => {
		const TestActorWithEvents = Actor.make("TestWorkflow", {
			actions: [Ping],
			events: [Moved],
		});

		expectTypeOf(TestWorkflow.client).toEqualTypeOf(
			TestActorWithEvents.client,
		);
		expectTypeOf(TestWorkflow.sql).toEqualTypeOf(TestActorWithEvents.sql);
		expectTypeOf(TestWorkflow.events).toEqualTypeOf(
			TestActorWithEvents.events,
		);
		expectTypeOf(TestWorkflow.schedule).toEqualTypeOf(
			TestActorWithEvents.schedule,
		);
		expectTypeOf(TestWorkflow.cron).toEqualTypeOf(TestActorWithEvents.cron);
		expectTypeOf(TestWorkflow.connections).toEqualTypeOf(
			TestActorWithEvents.connections,
		);
	});

	test("a rollback gets the step result, tryStep and try fail with their failures, and join and race keep the type of each branch", () => {
		const charge = Workflow.step("charge", Effect.succeed(1), {
			rollback: (amount) => {
				expectTypeOf(amount).toEqualTypeOf<number>();
				return Effect.asVoid(SomeDep);
			},
		});
		expectTypeOf(charge).toEqualTypeOf<
			Effect.Effect<number, never, SomeDep | Workflow.Workflow>
		>();
		expectTypeOf(
			Workflow.tryStep("send", Effect.succeed("sent")),
		).toEqualTypeOf<
			Effect.Effect<string, Workflow.StepFailure, Workflow.Workflow>
		>();
		expectTypeOf(
			Workflow.try("notify", Workflow.step("send", Effect.succeed(1))),
		).toEqualTypeOf<
			Effect.Effect<number, Workflow.TryFailure, Workflow.Workflow>
		>();

		const joined = Workflow.join("checks", {
			stock: Workflow.step("stock", Effect.succeed(1)),
			dep: Workflow.step("dep", SomeDep),
		});
		expectTypeOf(joined).toEqualTypeOf<
			Effect.Effect<
				{
					readonly stock: number;
					readonly dep: { readonly x: number };
				},
				never,
				SomeDep | Workflow.Workflow
			>
		>();
		const raced = Workflow.race("approval", {
			approved: Workflow.step("approve", Effect.succeed("alice")),
			rejected: Workflow.step("reject", Effect.succeed(false)),
		});
		expectTypeOf(raced).toEqualTypeOf<
			Effect.Effect<
				| { readonly winner: "approved"; readonly value: string }
				| { readonly winner: "rejected"; readonly value: boolean },
				never,
				Workflow.Workflow
			>
		>();
		Workflow.join("unhandled", {
			// @ts-expect-error: a branch must handle the failure of tryStep
			send: Workflow.tryStep("send", Effect.succeed(1)),
		});
	});

	test("a step outside the workflow leaves Workflow as a requirement", () => {
		const live = TestActor.toLayer(
			TestActor.of({
				Ping: () => Workflow.step("ping", Effect.succeed(1)),
			}),
		);

		expectTypeOf<Layer.Services<typeof live>>().toEqualTypeOf<
			Workflow.Workflow | Registry.Registry
		>();
	});
});
